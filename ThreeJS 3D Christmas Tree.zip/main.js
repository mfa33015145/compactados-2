document.querySelector(".preview").addEventListener("load", function() {
    document.querySelector(".loading-placeholder").style.display = "none";
  })